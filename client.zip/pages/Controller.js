import Delete from "@/src/Icons/delete";
import Edit from "@/src/Icons/edit";
import Mor from "@/src/Icons/mor";
import Reg from "@/src/Icons/reg";
import FormController from "@/src/components/c-crud/c-controller";
import DeleteForm from "@/src/components/c-crud/c-deleteForm";
import Header from "@/src/components/c-header/c-header";
import { useEffect, useState } from "react";

export default function Controller({ roles, token, IdUser }) {

  const successMessage = "Controlador eliminado";

  const onDelete = (id) => `${process.env.API_URL}/api/v1/controller/${id}`;
  
  const [controller, setController] = useState({
    controllers: [],
    empresas: [],
  });
  const [userToEdit, setUserToEdit] = useState("");
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [isPopupCreate, setIsPopupCreate] = useState(false);
  const [isPopupDelete, setIsPopupDelete] = useState(false);
  const [isCreateUser, setIsCreateUser] = useState(false);
  const [userToDeleteId, setUserToDeleteId] = useState(null);

  const closePopup = () => {
    setIsPopupOpen(false);
  };

  const closePopupDelete = () => {
    setIsPopupDelete(false);
  };

  const closePopupCreate = () => {
    setIsPopupCreate(false);
  };

  const fetchController = async () => {
    try {
      const response = await fetch(`${process.env.API_URL}/api/v1/controller`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "x-access-token": token,
        },
      });

      if (response.ok) {
        const data = await response.json();
       console.log(data);
        setController(data);
        setController({
          controllers: data.controllers,
          empresas: data.empresas,
        });
      } else {
        console.error("Error al obtener datos:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };
  useEffect(() => {
    fetchController();
  }, []);


  const { controllers, empresas } = controller;

  const handleEdit = async (userId) => {
    try {
      const response = await fetch(
        `${process.env.API_URL}/api/v1/controller/${userId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-access-token": token,
          },
        }
      );

      if (response.ok) {
        const userData = await response.json();
        setUserToEdit(userData);
        setIsPopupOpen(true);
        setIsCreateUser(false);
      } else {
        console.error("Error al obtener datos:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const handleDelete = async (userId) => {
    try {
      setIsPopupDelete(true);
      setUserToDeleteId(userId);
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  return (
    <>
      <Header roles={roles} />
      <section className="w-FormUser">
        <div className="Cont">
          <div className="Content-header">
            <div className="D-title-name">
              <div>
                <Reg />
              </div>
              <h3>Lista de controladores |</h3>
              <h4>Sensores</h4>
            </div>
          </div>
          <div className="Content-search">
            <input
              type="text"
              name="name"
              inputMode="text"
              className="input"
              placeholder="Buscar controlador..."
              required
            />
            <button onClick={() => setIsPopupCreate(true)}>
              <Mor /> Crear nuevo
            </button>
          </div>
          <div className="D-FormUser">
            <table>
              <thead>
                <tr>
                  <th>Serie</th>
                  <th>Mina</th>
                  <th>Ubicación</th>
                  <th>Nivel</th>
                  <th>Top</th>
                  <th>Left</th>
                  <th>Usuario</th>
                  <th>Fecha de creación</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {controllers.length === 0 ? (
                  <>
                    <tr>
                      <td>No hay datos</td>
                    </tr>
                  </>
                ) : (
                  controllers.map((contr, index) => (
                    <tr key={index}>
                      <td>{contr.serie}</td>                      
                       <td>{contr.mining.name ? contr.mining.name : 'Ninguno'}</td> 
                      <td>{contr.ubication}</td>
                      <td>{contr.level}</td>
                      <td>{contr.top}</td>
                      <td>{contr.left}</td>
                      <td>{contr.userId.name}</td>
                      <td>
                        {new Date(contr.createdAt)
                          .toLocaleString(undefined, {
                            month: "long",
                            day: "numeric",
                            hour: "numeric",
                            minute: "numeric",
                            second: "numeric",
                            hour12: true,
                          })
                          .replace(",", " -")}
                      </td>
                      <td className="t-actions">
                        <button className="btn-delet"
                        onClick={() => handleDelete(contr._id)}>
                          <Delete />
                        </button>
                        <button
                          className="btn-edit"
                          onClick={() => handleEdit(contr._id)}
                        >
                          <Edit />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
        {isPopupOpen && (
          <FormController
            initialValues={userToEdit}
            onClose={closePopup}
            token={token}
            fetchController={fetchController}
            isCreateUser={isCreateUser}
            userToEdit={userToEdit}
            empresas={empresas}
            IdUser={IdUser}
          />
        )}
        {isPopupCreate && (
          <FormController
            onClose={closePopupCreate}
            token={token}
            fetchController={fetchController}
            isCreateUser={true}
            userToEdit={userToEdit}
            empresas={empresas}
            IdUser={IdUser}
          />
        )}
        {isPopupDelete && (
          <DeleteForm
            onClose={closePopupDelete}
            token={token}
            userToDeleteId={userToDeleteId}
            fetchController={fetchController}
          />
        )}
      </section>
    </>
  );
}

export async function getServerSideProps(ctx) {
  const userDataCookie = ctx.req.cookies.userData;
  const isLoggedIn = !!userDataCookie;

  if (!isLoggedIn) {
    return {
      redirect: {
        destination: "/Login",
        permanent: false,
      },
    };
  }

  const userData = JSON.parse(userDataCookie);
  const roles = userData.roles;
  const token = userData.token;
  const isAdmin = roles.some((role) => role.name === "admin");

  if (!isAdmin) {
    return {
      redirect: {
        destination: "/safety",
        permanent: false,
      },
    };
  }

  return {
    props: {
      roles,
      token,
    },
  };
}

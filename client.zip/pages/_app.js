import { Font, JetBrains_Mono } from "@next/font/google";
import { MainProvider } from "@/src/contexts/Main-context";
import Foot from "@/src/components/c-footer/c-footer";
import "@/src/global.scss";
import Layout from "@/src/layout";

const inter = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["200", "400", "700"],
});

function App({ Component, pageProps }) {
  return (
    <Layout>
      <main className={inter.className}>
        <MainProvider globalData={pageProps.globalData}>
          <Component {...pageProps} />
        </MainProvider>
      </main>
    </Layout>
  );
}

export default App;

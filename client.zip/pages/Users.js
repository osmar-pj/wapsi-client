import Delete from "@/src/Icons/delete";
import Edit from "@/src/Icons/edit";
import Mor from "@/src/Icons/mor";
import Reg from "@/src/Icons/reg";
import DeleteForm from "@/src/components/c-crud/c-deleteForm";
import FormList from "@/src/components/c-crud/c-list";
import FormUser from "@/src/components/c-crud/c-user";
import Header from "@/src/components/c-header/c-header";
import { useEffect, useState } from "react";

export default function Users({ roles, token }) {
  const [users, setUsers] = useState({
    usersFiltered2: [],
    rolesFiltered: [],
    empresas: [],
  });
  const [userToEdit, setUserToEdit] = useState("");
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [isPopupCreate, setIsPopupCreate] = useState(false);
  const [isPopupDelete, setIsPopupDelete] = useState(false);
  const [isCreateUser, setIsCreateUser] = useState(false);
  const [userToDeleteId, setUserToDeleteId] = useState(null);

  const closePopup = () => {
    setIsPopupOpen(false);
  };

  const closePopupCreate = () => {
    setIsPopupCreate(false);
  };

  const closePopupDelete = () => {
    setIsPopupDelete(false);
  };

  const fetchUsers = async () => {
    try {
      const response = await fetch(`${process.env.API_URL}/api/v1/user`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "x-access-token": token,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setUsers({
          usersFiltered2: data.usersFiltered2,
          rolesFiltered: data.rolesFiltered,
          empresas: data.empresas,
        });
      } else {
        console.error("Error al obtener datos:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const { usersFiltered2, rolesFiltered, empresas } = users;

  const handleEdit = async (userId) => {
    try {
      const response = await fetch(
        `${process.env.API_URL}/api/v1/user/${userId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-access-token": token,
          },
        }
      );

      if (response.ok) {
        const userData = await response.json();
        setUserToEdit(userData);
        setIsPopupOpen(true);
        setIsCreateUser(false);
      } else {
        console.error("Error al obtener datos:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const handleDelete = async (userId) => {
    try {
      setIsPopupDelete(true);
      setUserToDeleteId(userId);
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  return (
    <>
      <Header roles={roles} />
      <section className="w-FormUser">
        <div className="Cont">
          <div className="Content-header">
            <div className="D-title-name">
              <div>
                <Reg />
              </div>
              <h3>Lista de usuarios |</h3>
              <h4>Empresa</h4>
            </div>
          </div>
          <div className="Content-search">
            <input
              type="text"
              name="name"
              inputMode="text"
              className="input"
              placeholder="Buscar usuario..."
              required
            />
            <button onClick={() => setIsPopupCreate(true)}>
              <Mor />
              Crear nuevo
            </button>
          </div>

          <div className="D-FormUser">
            {/* <FormList
             data={usersFiltered2}
             onDelete={handleDelete}
             onEdit={handleEdit}
             headers={["serie", "mining.name", "ubication", "level", "top", "left", "userId.name", "createdAt"]}
             noDataMessage="No hay datos"
            /> */}
            <table>
              <thead>
                <tr>
                  <th>Siglas</th>
                  <th>Nombre</th>
                  <th>Apellido</th>
                  <th>DNI</th>
                  <th>Roles</th>
                  <th>Empresa</th>
                  <th>Área</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {usersFiltered2.length === 0 ? (
                  <>
                    <tr>
                      <td>No hay datos</td>
                    </tr>
                  </>
                ) : (
                  usersFiltered2.map((user, index) => (
                    <tr key={index}>
                      <td>
                        <span className="t-siglas">
                          {getInitials(user.name)}
                          {getInitials(user.lastname)}
                        </span>
                      </td>
                      <td>{user.name}</td>
                      <td>{user.lastname}</td>
                      <td>{user.dni}</td>
                      <td>
                        {user.roles.map((r, index) => (
                          <span className="role-item" key={index}>
                            {r.name}
                          </span>
                        ))}
                      </td>
                      <td>{user.empresa}</td>
                      <td>{user.area} </td>
                      <td className="t-actions">
                        <button
                          className="btn-delet"
                          onClick={() => handleDelete(user._id)}
                        >
                          <Delete />
                        </button>
                        <button
                          className="btn-edit"
                          onClick={() => handleEdit(user._id)}
                        >
                          <Edit />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
        {isPopupOpen && (
          <FormUser
            initialValues={userToEdit}
            onClose={closePopup}
            token={token}
            fetchUsers={fetchUsers}
            rolesFiltered={rolesFiltered}
            empresas={empresas}
            isCreateUser={isCreateUser}
            userToEdit={userToEdit}
          />
        )}
        {isPopupCreate && (
          <FormUser
            onClose={closePopupCreate}
            token={token}
            fetchUsers={fetchUsers}
            rolesFiltered={rolesFiltered}
            empresas={empresas}
            isCreateUser={true}
            userToEdit={userToEdit}
          />
        )}
        {isPopupDelete && (
          <DeleteForm
            onClose={onClose}
            token={token}
            onDelete={onDelete}
            successMessage={successMessage}
            fetchFunction={fetchController}
            userToDeleteId={userToDeleteId}
          />
        )}
      </section>
    </>
  );
}

const getInitials = (name) => {
  const names = name.split(" ");
  return names[0][0];
};

export async function getServerSideProps(ctx) {
  const userDataCookie = ctx.req.cookies.userData;
  const isLoggedIn = !!userDataCookie;

  if (!isLoggedIn) {
    return {
      redirect: {
        destination: "/Login",
        permanent: false,
      },
    };
  }

  const userData = JSON.parse(userDataCookie);
  const roles = userData.roles;
  const token = userData.token;
  const isAdmin = roles.some((role) => role.name === "admin");

  if (!isAdmin) {
    return {
      redirect: {
        destination: "/safety",
        permanent: false,
      },
    };
  }

  return {
    props: {
      roles,
      token,
    },
  };
}

import Reg from "@/src/Icons/reg";
import Header from "@/src/components/c-header/c-header";
import Popup from "@/src/components/c-popup/c-popup";
import { useRouter } from "next/router";
import { useState } from "react";
import Select from "react-select";

export default function Formu({ userId, roles }) {
  const [area, setArea] = useState("");
  const [successModalVisible, setSuccessModalVisible] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  const router = useRouter();

  const options = [
    { value: "safety", label: "Seguridad" },
    { value: "ti", label: "TI" },
    { value: "ventilation", label: "Ventilación" },
    { value: "operation", label: "Operaciones" },
  ];

  const handleAreaChange = ({ value }) => {
    setArea(value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!area) {
      console.log("Por favor, ingrese una descripción.");
      return;
    }

    try {
      const response = await fetch(
        `${process.env.API_URL}/api/v1/user/${userId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({ area: area }),
        }
      );

      if (response.ok) {
        const data = await response.json();

        setSuccessMessage("Área actualizado");
        setSuccessModalVisible(true);
        setTimeout(() => {
          setSuccessMessage("");
          router.push(`/${area}`);
          setSuccessModalVisible(false);
        }, 3000);
      } else {
        console.error("Error al actualizar recurso:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const customStyles = {
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isSelected
        ? "rgba(10, 66, 60, 0.4)"
        : state.isFocused
        ? "#2e394d"
        : "#0022375e",
      color: state.isSelected ? "rgb(11, 185, 125)" : "#9ea2a8",
      padding: "10px 18px",
    }),
    control: (provided, state) => ({
      ...provided,
      backgroundColor: state.isFocused ? "rgba(10, 66, 60, 0.4)" : "#0022375e",
      boxShadow: state.isFocused ? "none" : provided.boxShadow,
      cursor: "pointer",
      minHeight: "50px",
      padding: "0 10px",
      border: "none",
    }),
    singleValue: (provided) => ({
      ...provided,
      color: "#9ea2a8",
    }),
    menu: (provided) => ({
      ...provided,
      backgroundColor: "#001320",
    }),
    indicatorSeparator: (provided) => ({
      ...provided,
      display: "none",
    }),
    dropdownIndicator: (provided, state) => ({
      ...provided,
      width: "auto",
      height: "20px",
      padding: "0 5px",
      alignItems: "center",
      color: state.isFocused ? "#9ea2a8" : "#9ea2a8",
      "& svg": {
        width: "12px",
        height: "12px",
      },
    }),
  };

  return (
    <>
      <Header roles={roles} />
      <section className="w-Home">
        {successModalVisible ? (
          <Popup
            title="Acción exitosa!"
            message={successMessage}
            visible={successModalVisible}
          />
        ) : (
          <div className="Update-area">
          <div className="Content-header">
            <div className="D-title-name">
              <div>
                <Reg />
              </div>
              <h3>Actualizar área |</h3>
              <h4>update</h4>
            </div>
          </div>
          <form onSubmit={handleSubmit} className="form-l">
            <h3>Seleccione el área al que pertenece</h3>
            <div className="select-area">
              <Select
                instanceId="react-select-instance"
                name="period"
                className="select"
                isSearchable={false}
                isClearable={false}
                onChange={handleAreaChange}
                options={options}
                styles={customStyles}
              />
            </div>
            <button type="submit">Guardar</button>
          </form>
          </div>
        )}
      </section>
    </>
  );
}

export const getServerSideProps = async (ctx) => {
  const userDataCookie = ctx.req.cookies.userData;
  const isLoggedIn = !!userDataCookie;

  if (!isLoggedIn) {
    return {
      redirect: {
        destination: "/Login",
        permanent: false,
      },
    };
  }

  const userData = JSON.parse(userDataCookie);
  const area = userData.area;
  const userId = userData.userId;
  const roles = userData.roles;

  if (typeof area !== "undefined" && area !== "") {
    return {
      redirect: {
        destination: `/${area}`,
        permanent: false,
      },
    };
  } else {
    return {
      props: {
        area: null,
        userId,
        roles,
      },
    };
  }
};

import Delete from "@/src/Icons/delete";
import Edit from "@/src/Icons/edit";
import Reg from "@/src/Icons/reg";
import FormCompany from "@/src/components/c-crud/c-company";
import DeleteForm from "@/src/components/c-crud/c-deleteForm";
import Header from "@/src/components/c-header/c-header";
import { useEffect, useState } from "react";

export default function Company({ roles, token }) {
  const successMessage = "Empresa eliminada";

  const onDelete = (id) => `${process.env.API_URL}/api/v1/empresa/${id}`;

  const [company, setCompany] = useState("");
  const [userToEdit, setUserToEdit] = useState("");
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [isPopupCreate, setIsPopupCreate] = useState(false);
  const [isPopupDelete, setIsPopupDelete] = useState(false);
  const [isCreateUser, setIsCreateUser] = useState(false);
  const [userToDeleteId, setUserToDeleteId] = useState(null);

  const closePopup = () => {
    setIsPopupOpen(false);
  };

  const closePopupDelete = () => {
    setIsPopupDelete(false);
  };

  const closePopupCreate = () => {
    setIsPopupCreate(false);
  };

  const fetchCompany = async () => {
    try {
      const response = await fetch(`${process.env.API_URL}/api/v1/empresa`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "x-access-token": token,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setCompany(data);
      } else {
        console.error("Error al obtener datos:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };
  useEffect(() => {
    fetchCompany();
  }, []);

  console.log(company);

  const handleEdit = async (userId) => {
    try {
      const response = await fetch(
        `${process.env.API_URL}/api/v1/empresa/${userId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-access-token": token,
          },
        }
      );

      if (response.ok) {
        const userData = await response.json();
        setUserToEdit(userData);
        setIsPopupOpen(true);
        setIsCreateUser(false);
      } else {
        console.error("Error al obtener datos:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const handleDelete = async (userId) => {
    try {
      setIsPopupDelete(true);
      setUserToDeleteId(userId);
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  return (
    <>
      <Header roles={roles} />
      <section className="w-FormUser">
        <div className="Cont">
          <div className="Content-header">
            <div className="D-title-name">
              <div>
                <Reg />
              </div>
              <h3>Lista de empresas |</h3>
              <h4>Empresa</h4>
            </div>
          </div>
          <div className="Content-search">
            <input
              type="text"
              name="name"
              inputMode="text"
              className="input"
              placeholder="Buscar empresa..."
              required
            />
            <button onClick={() => setIsPopupCreate(true)}>Crear nuevo</button>
          </div>

          <div className="D-FormUser">
            <table>
              <thead>
                <tr>
                  <th>RUC</th>
                  <th>Nombre</th>
                  <th>Dirección</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {company.length === 0 ? (
                  <>
                    <tr>
                      <td>No hay datos</td>
                    </tr>
                  </>
                ) : (
                  company.map((comp, index) => (
                    <tr key={index}>
                      <td>{comp.ruc}</td>
                      <td>{comp.name}</td>
                      <td>{comp.address}</td>
                      <td
                        className="t-actions"
                        onClick={() => handleDelete(comp._id)}
                      >
                        <button className="btn-delet">
                          <Delete />
                        </button>
                        <button
                          className="btn-edit"
                          onClick={() => handleEdit(comp._id)}
                        >
                          <Edit />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
        {isPopupOpen && (
          <FormCompany
            initialValues={userToEdit}
            onClose={closePopup}
            token={token}
            fetchCompany={fetchCompany}
            isCreateUser={isCreateUser}
            userToEdit={userToEdit}
          />
        )}
        {isPopupCreate && (
          <FormCompany
            onClose={closePopupCreate}
            token={token}
            fetchCompany={fetchCompany}
            isCreateUser={true}
            userToEdit={userToEdit}
          />
        )}
        {isPopupDelete && (
          <DeleteForm
            onClose={onClose}
            token={token}
            onDelete={onDelete}
            successMessage={successMessage}
            fetchFunction={fetchCompany}
            userToDeleteId={userToDeleteId}
          />
        )}
      </section>
    </>
  );
}

export async function getServerSideProps(ctx) {
  const userDataCookie = ctx.req.cookies.userData;
  const isLoggedIn = !!userDataCookie;

  if (!isLoggedIn) {
    return {
      redirect: {
        destination: "/Login",
        permanent: false,
      },
    };
  }

  const userData = JSON.parse(userDataCookie);
  const roles = userData.roles;
  const token = userData.token;
  const isAdmin = roles.some((role) => role.name === "admin");

  if (!isAdmin) {
    return {
      redirect: {
        destination: "/safety",
        permanent: false,
      },
    };
  }

  return {
    props: {
      roles,
      token,
    },
  };
}

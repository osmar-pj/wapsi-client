import { useEffect, useState } from "react";
import Select from "react-select";
import Popup from "../c-popup/c-popup";
import Reg from "@/src/Icons/reg";

export default function FormUser({
  onClose,
  token,
  fetchUsers,
  rolesFiltered,
  empresas,
  isCreateUser,
  userToEdit,
}) {
  const initialValues = isCreateUser
    ? {
        empresa: "",
        name: "",
        lastname: "",
        dni: "",
        roles: [],
      }
    : {
        empresa: userToEdit.empresa, 
        name: userToEdit.name,
        lastname: userToEdit.lastname,
        dni: userToEdit.dni,
        roles: userToEdit.roles.map((rol) => rol._id), 
      };

  const [formData, setFormData] = useState(initialValues);
  const [successModalVisible, setSuccessModalVisible] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    if (!isCreateUser && userToEdit) {
      setFormData({
        empresa: userToEdit.empresa,
        name: userToEdit.name,
        lastname: userToEdit.lastname,
        dni: userToEdit.dni,
        roles: userToEdit.roles.map((rol) => rol._id),
      });
    }
  }, [isCreateUser, userToEdit]);


  const optionsEmpresas = empresas.map((emp) => ({
    value: emp.name,
    label: emp.name,
  }));

  const optionsRoles = rolesFiltered.map((rol) => ({
    value: rol._id,
    label: rol.name,
  }));

  const handleRolesChange = (selectedOptions) => {
    const selectedRoleValues = selectedOptions.map((option) => option.value);
    setFormData({
      ...formData,
      roles: selectedRoleValues,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (isCreateUser) {
      handleCreateUser();
    } else {
      handleUpdateUser();
    }
  };

  const handleCreateUser = async () => {
    try {
      const response = await fetch(
        `${process.env.API_URL}/auth/api/v1/signup`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-access-token": token,
          },
          body: JSON.stringify(formData),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setSuccessMessage("Usuario creado");
        setSuccessModalVisible(true);
        fetchUsers();
        setTimeout(() => {
          setSuccessModalVisible(false);
          setSuccessMessage("");
          onClose();
        }, 2500);
      } else {
        console.error("Error al crear el usuario:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const handleUpdateUser = async () => {
    try {
      const response = await fetch(
        `${process.env.API_URL}/api/v1/user/${userToEdit._id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-access-token": token,
          },
          body: JSON.stringify(formData),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setSuccessMessage("Usuario actualizado");
        setSuccessModalVisible(true);
        fetchUsers();

        setTimeout(() => {
          setSuccessModalVisible(false);
          setSuccessMessage("");
          onClose();
        }, 2500);
      } else {
        console.error("Error al actualizar el usuario:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const handleAreaChange = (selectedOption) => {
    setFormData({
      ...formData,
      empresa: selectedOption.value, 
    });
  };

  const customStyles = {
    option: (provided, state) => ({
      ...provided,
      className: "custom-select__option",
    }),
    control: (provided, state) => ({
      ...provided,
      className: "custom-select__control",
    }),
  };

  return (
    <div className="popupOverlay">
      {successModalVisible ? (
        <Popup
          title="Acción exitosa!"
          message={successMessage}
          visible={successModalVisible}
          
        />
      ) : (
        <div className="popupContent">
          <div className="Content-header">
            <div className="D-title-name">
              <div>
                <Reg />
              </div>
              <h3>{isCreateUser ? "Crear usuario |" : "Actualizar usuario |"}</h3>
              <h4>{isCreateUser ? "Create" : "Update"}</h4>
            </div>
          </div>
          <span onClick={onClose}>&times;</span>
          <form onSubmit={handleSubmit} className="upd-m-content">
            <input
              type="text"
              name="name"
              inputMode="text"
              className="input-f"
              placeholder="Ingrese Nombre"
              required
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
            />

            <input
              type="text"
              name="lastname"
              inputMode="text"
              className="input-f"
              placeholder="Ingrese Apellido"
              required
              value={formData.lastname}
              onChange={(e) =>
                setFormData({ ...formData, lastname: e.target.value })
              }
            />

            <input
              type="text"
              name="code"
              pattern="[0-9]*"
              maxLength={8}
              inputMode="numeric"
              className="input-f"
              placeholder="Ingrese DNI"
              required
              value={formData.dni}
              onChange={(e) =>
                setFormData({ ...formData, dni: e.target.value })
              }
            />

            <div className="select-g">
              <Select
                instanceId="react-select-instance"
                name="period"
                classNamePrefix="custom-select"
                isSearchable={false}
                isClearable={false}
                onChange={handleAreaChange}
                options={optionsEmpresas}
                value={optionsEmpresas.find((opt) => opt.value === formData.empresa)} 
                styles={customStyles}
              />
            </div>
            <div className="select-g">
              <Select
                instanceId="react-select-instance"
                name="roles"
                classNamePrefix="custom-select"
                isSearchable={false}
                isClearable={false}
                isMulti
                onChange={handleRolesChange}
                options={optionsRoles}
                value={optionsRoles.filter((opt) =>
                  formData.roles.includes(opt.value)
                )} 
                styles={customStyles}
              />
            </div>
            <div className="updt-input">
              <button className="btn-cancel" type="button" onClick={onClose}>
                Cancelar
              </button>
              <button className="btn-acept" type="submit">
                {isCreateUser ? "Crear" : "Actualizar"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

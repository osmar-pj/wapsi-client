import { useEffect, useState } from "react";
import Popup from "../c-popup/c-popup";
import Reg from "@/src/Icons/reg";

export default function FormCompany({
  onClose,
  token,
  fetchCompany,
  isCreateUser,
  userToEdit,
}) {
  const initialValues = isCreateUser
    ? {
        ruc: "",
        name: "",
        address: "",
      }
    : {
        ruc: userToEdit.ruc,
        name: userToEdit.name,
        address: userToEdit.address,
      };

  const [formData, setFormData] = useState(initialValues);
  const [successModalVisible, setSuccessModalVisible] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    if (!isCreateUser && userToEdit) {
      setFormData({
        ruc: userToEdit.ruc,
        name: userToEdit.name,
        address: userToEdit.address,
      });
    }
  }, [isCreateUser, userToEdit]);


  const handleSubmit = (event) => {
    event.preventDefault();
    if (isCreateUser) {
      handleCreateUser();
    } else {
      handleUpdateUser();
    }
  };

  const handleCreateUser = async () => {
    try {
      const response = await fetch(
        `${process.env.API_URL}/api/v1/empresa`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-access-token": token,
          },
          body: JSON.stringify(formData),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setSuccessMessage("Empresa creado");
        setSuccessModalVisible(true);
        fetchCompany();
        setTimeout(() => {
          setSuccessModalVisible(false);
          setSuccessMessage("");
          onClose();
        }, 3000);
      } else {
        console.error("Error al crear la empresa:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const handleUpdateUser = async () => {
    try {
      const response = await fetch(
        `${process.env.API_URL}/api/v1/empresa/${userToEdit._id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-access-token": token,
          },
          body: JSON.stringify(formData),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setSuccessMessage("Empresa actualizado");
        setSuccessModalVisible(true);
        fetchCompany();

        setTimeout(() => {
          setSuccessModalVisible(false);
          setSuccessMessage("");
          onClose();
        }, 3000);
      } else {
        console.error("Error al actualizar la empresa:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const customStyles = {
    option: (provided, state) => ({
      ...provided,
      className: "custom-select__option",
    }),
    control: (provided, state) => ({
      ...provided,
      className: "custom-select__control",
    }),
  };


  return (
    <div className="popupOverlay">
      {successModalVisible ? (
        <Popup
          title="Acción exitosa!"
          message={successMessage}
          visible={successModalVisible}
        />
      ) : (
        <div className="popupContent">
          <div className="Content-header">
            <div className="D-title-name">
              <div>
                <Reg />
              </div>
              <h3>{isCreateUser ? "Crear empresa |" : "Actualizar empresa |"}</h3>
              <h4>{isCreateUser ? "Create" : "Update"}</h4>
            </div>
          </div>
          <span onClick={onClose}>&times;</span>
          <form onSubmit={handleSubmit} className="upd-m-content">
            <input
              type="text"
              name="ruc"
              inputMode="text"
              className="input-f"
              placeholder="Ingrese RUC"
              required
              value={formData.ruc}
              onChange={(e) =>
                setFormData({ ...formData, ruc: e.target.value })
              }
            />
            <input
              type="text"
              name="name"
              inputMode="text"
              className="input-f"
              placeholder="Ingrese Nombre"
              required
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
            />
            <input
              type="text"
              name="address"
              inputMode="text"
              className="input-f"
              placeholder="Ingrese Dirección"
              required
              value={formData.address}
              onChange={(e) =>
                setFormData({ ...formData, address: e.target.value })
              }
            />
            <div className="updt-input">
              <button className="btn-cancel" type="button" onClick={onClose}>
                Cancelar
              </button>
              <button className="btn-acept" type="submit">
                {isCreateUser ? "Crear" : "Actualizar"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

import React from "react";
import Delete from "@/src/Icons/delete";
import Edit from "@/src/Icons/edit";

export default function FormList({
  data,
  onDelete,
  onEdit,
  headers,
  noDataMessage,
}) {
  return (
    <table>
      <thead>
        <tr>
          {headers.map((header, index) => (
            <th key={index}>{header}</th>
          ))}
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        {data.length === 0 ? (
          <tr>
            <td colSpan={headers.length + 1}>{noDataMessage}</td>
          </tr>
        ) : (
          data.map((item, index) => (
            <tr key={index}>
              {/* Renderiza las celdas de datos según los encabezados */}
              {headers.map((header, index) => (
                <td key={index}>{item[header]}</td>
              ))}
              <td className="t-actions">
                <button className="btn-delet" onClick={() => onDelete(item.id)}>
                  <Delete />
                </button>
                <button className="btn-edit" onClick={() => onEdit(item.id)}>
                  <Edit />
                </button>
              </td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  );
}

import { useEffect, useState } from "react";
import Select from "react-select";
import Popup from "../c-popup/c-popup";
import Reg from "@/src/Icons/reg";

export default function FormController({
  onClose,
  token,
  fetchController,
  isCreateUser,
  userToEdit,
  empresas,
  IdUser,
}) {
  const initialValues = isCreateUser
    ? {
        serie: "",
        mining: "",
        ubication: "",
        level: "",
        top: "",
        left: "",
        userId: IdUser,
      }
    : {
        serie: userToEdit.serie, 
        mining: userToEdit.mining,
        ubication: userToEdit.ubication,
        level: userToEdit.level,
        top: userToEdit.top,
        left: userToEdit.left,
        userId: IdUser,
      };

  const [formData, setFormData] = useState(initialValues);
  const [successModalVisible, setSuccessModalVisible] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    if (!isCreateUser && userToEdit) {
      setFormData({
        serie: userToEdit.serie,
        mining: userToEdit.mining,
        ubication: userToEdit.ubication,
        level: userToEdit.level,
        top: userToEdit.top,
        left: userToEdit.left,
        userId: IdUser,
      });
    }
  }, [isCreateUser, userToEdit]);

  const optionsEmpresas = empresas.map((emp) => ({
    value: emp._id,
    label: emp.name,
  }));

  const handleSubmit = (event) => {
    event.preventDefault();
    if (isCreateUser) {
      handleCreateUser();
    } else {
      handleUpdateUser();
    }
  };

  const handleCreateUser = async () => {
    try {
      const response = await fetch(`${process.env.API_URL}/api/v1/controller`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "x-access-token": token,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data = await response.json();
        setSuccessMessage("Controlador creado");
        setSuccessModalVisible(true);
        fetchController();
        setTimeout(() => {
          setSuccessModalVisible(false);
          setSuccessMessage("");
          onClose();
        }, 3000);
      } else {
        console.error("Error al crear el controlador:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const handleUpdateUser = async () => {
    try {
      const response = await fetch(
        `${process.env.API_URL}/api/v1/controller/${userToEdit._id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-access-token": token,
          },
          body: JSON.stringify(formData),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setSuccessMessage("Controlador actualizado");
        setSuccessModalVisible(true);
        fetchController();

        setTimeout(() => {
          setSuccessModalVisible(false);
          setSuccessMessage("");
          onClose();
        }, 3000);
      } else {
        console.error(
          "Error al actualizar el controlador:",
          response.statusText
        );
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  const handleAreaChange = (selectedOption) => {
    setFormData({
      ...formData,
      mining: selectedOption.value,
    });
  };

  const customStyles = {
    option: (provided, state) => ({
      ...provided,
      className: "custom-select__option",
    }),
    control: (provided, state) => ({
      ...provided,
      className: "custom-select__control",
    }),
  };

  return (
    <div className="popupOverlay">
      {successModalVisible ? (
        <Popup
          title="Acción exitosa!"
          message={successMessage}
          visible={successModalVisible}
        />
      ) : (
        <div className="popupContent">
          <div className="Content-header">
            <div className="D-title-name">
              <div>
                <Reg />
              </div>
              <h3>
                {isCreateUser ? "Crear controlador |" : "Actualizar controlador |"}
              </h3>
              <h4>{isCreateUser ? "Create" : "Update"}</h4>
            </div>
          </div>
          <span onClick={onClose}>&times;</span>
          <form onSubmit={handleSubmit} className="upd-m-content">
            <input
              type="text"
              name="name"
              inputMode="text"
              className="input-f"
              placeholder="Ingrese Serie"
              required
              value={formData.serie}
              onChange={(e) =>
                setFormData({ ...formData, serie: e.target.value })
              }
            />

            <div className="select-g">
              <Select
                instanceId="react-select-instance"
                name="period"
                classNamePrefix="custom-select"
                isSearchable={false}
                isClearable={false}
                onChange={handleAreaChange}
                options={optionsEmpresas}
                value={optionsEmpresas.find(
                  (opt) => opt.value === formData.mining
                )}
                styles={customStyles}
              />
            </div>

           
            <input
              type="text"
              name="ubication"
              inputMode="text"
              className="input-f"
              placeholder="Ingrese Ubicación"
              required
              value={formData.ubication}
              onChange={(e) =>
                setFormData({ ...formData, ubication: e.target.value })
              }
            />

            <input
              type="text"
              name="level"
              inputMode="text"
              className="input-f"
              placeholder="Ingrese Nivel"
              required
              value={formData.level}
              onChange={(e) =>
                setFormData({ ...formData, level: e.target.value })
              }
            />
            <input
              type="text"
              name="code"
              pattern="[0-9]*"
              maxLength={8}
              inputMode="numeric"
              className="input-f"
              placeholder="Ingrese Top"
              required
              value={formData.top}
              onChange={(e) =>
                setFormData({ ...formData, top: e.target.value })
              }
            />
            <input
              type="text"
              name="code"
              pattern="[0-9]*"
              maxLength={8}
              inputMode="numeric"
              className="input-f"
              placeholder="Ingrese Left"
              required
              value={formData.left}
              onChange={(e) =>
                setFormData({ ...formData, left: e.target.value })
              }
            />
            <div className="updt-input">
              <button className="btn-cancel" type="button" onClick={onClose}>
                Cancelar
              </button>
              <button className="btn-acept" type="submit">
                {isCreateUser ? "Crear" : "Actualizar"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

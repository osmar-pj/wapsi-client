import React, { useState } from "react";
import Popup from "../c-popup/c-popup";
import Reg from "@/src/Icons/reg";

export default function DeleteForm({
  onClose,
  token,
  onDelete,
  successMessage,
  fetchFunction,
  userToDeleteId,
}) {
  const [successModalVisible, setSuccessModalVisible] = useState(false);

  const handleDelete = async () => {
    try {
      const response = await fetch(onDelete(userToDeleteId), {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "x-access-token": token,
        },
      });

      if (response.ok) {
        setSuccessModalVisible(true);
        fetchFunction();

        setTimeout(() => {
          setSuccessModalVisible(false);
          onClose();
        }, 3000);

      } else {
        console.error("Error al eliminar dato:", response.statusText);
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
    }
  };

  return (
    <div className="popupOverlay">
      {successModalVisible ? (
        <Popup
          title="Acción exitosa!"
          message={successMessage}
          visible={successModalVisible}
        />
      ) : (
        <div className="popupContent">
          <div className="Content-header">
            <div className="D-title-name">
              <div>
                <Reg />
              </div>
              <h3>Eliminar |</h3>
              <h4>Delete</h4>
            </div>
          </div>
          <span onClick={onClose}>&times;</span>
          <div className="upd-m-content">
            <p>¿Seguro que quieres eliminar de la lista?</p>
            <div className="updt-input">
              <button className="btn-cancel" type="button" onClick={onClose}>
                No
              </button>
              <button className="btn-acept" type="button" onClick={handleDelete}>
                Sí
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
